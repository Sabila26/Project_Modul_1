      <footer class="footer">
          <div class="container">


              <div class="bottom-footer">
                  <div class="row">
                      <div class="col-xs-12 col-sm-4 address color-gray">
                          <h5>Alamat</h5>
                          <p>Jurang, Gebog, Kudus.</p>
                          <h5>Phone: 083843322435</a></h5>
                      </div>
                      <div class="col-xs-12 col-sm-5 additional-info color-gray">
                          <h5>Informasi Tambahan</h5>
                          <p>Join thousands of other restaurants who benefit from having partnered with us.</p>
                      </div>
                  </div>
              </div>

          </div>
      </footer>


      <!-- /*!
 *  Author Name: MH RONY.
 *  GigHub Link: https://github.com/dev-mhrony
 *  Facebook Link:https://www.facebook.com/dev.mhrony
 *  Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
    for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com  
 *  Visit My Website : developerrony.com 

      */ -->